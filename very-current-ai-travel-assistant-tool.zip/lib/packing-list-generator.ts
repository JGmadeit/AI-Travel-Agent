interface TripDetails {
  destination: string
  tripLength: string
  tripType: string
  specialNeeds?: string
}

interface PackingList {
  essentials: string[]
  clothing: string[]
  specialItems: string[]
}

// Helper function to extract number from string like "5 days" -> 5
function extractDays(tripLength: string): number {
  const match = tripLength.match(/\d+/)
  return match ? Number.parseInt(match[0], 10) : 7 // Default to 7 if no number found
}

export async function generatePackingList(tripDetails: TripDetails): Promise<PackingList> {
  const days = extractDays(tripDetails.tripLength)
  const tripType = tripDetails.tripType.toLowerCase()
  const destination = tripDetails.destination
  const specialNeeds = tripDetails.specialNeeds || ""

  // Base essentials for all trips
  const essentials = [
    "Passport/ID and wallet",
    "Phone + charger",
    "Toiletries kit",
    "Medications",
    "Travel insurance documents",
  ]

  // Add laptop for business trips
  if (tripType === "business") {
    essentials.push("Laptop + charger")
    essentials.push("Notebook and pen")
    essentials.push("Business cards")
  }

  // Base clothing calculation
  let clothing: string[] = [
    `${Math.ceil(days / 2)} pairs of pants/shorts`,
    `${days} shirts/tops`,
    `${days} sets of underwear`,
    `${days} pairs of socks`,
    "Sleepwear",
    "Comfortable walking shoes",
  ]

  // Trip type specific clothing
  if (tripType === "business") {
    clothing = [
      `${Math.min(days, 3)} business suits/formal outfits`,
      `${days - Math.min(days, 3)} business casual outfits`,
      `${days} sets of underwear`,
      `${days} pairs of socks`,
      "Sleepwear",
      "Dress shoes",
      "Comfortable walking shoes",
    ]
  } else if (tripType === "beach") {
    clothing.push("Swimwear")
    clothing.push("Beach cover-up")
    clothing.push("Sunglasses")
    clothing.push("Sun hat")
  } else if (tripType === "winter") {
    clothing.push("Winter coat/heavy jacket")
    clothing.push("Thermal underwear/base layers")
    clothing.push("Gloves/mittens")
    clothing.push("Scarf")
    clothing.push("Winter hat/beanie")
    clothing.push("Warm socks")
  } else if (tripType === "adventure") {
    clothing.push("Hiking boots/appropriate footwear")
    clothing.push("Weather-appropriate jacket")
    clothing.push("Quick-dry clothing")
    clothing.push("Hat for sun protection")
  }

  // Special items based on trip type and special needs
  const specialItems: string[] = []

  // Add items based on trip type
  if (tripType === "beach") {
    specialItems.push("Sunscreen")
    specialItems.push("Beach towel")
    specialItems.push("Beach bag")
  } else if (tripType === "adventure") {
    specialItems.push("Water bottle")
    specialItems.push("First aid kit")
    specialItems.push("Backpack")
    specialItems.push("Insect repellent")
  } else if (tripType === "business") {
    specialItems.push("Portfolio or presentation materials")
    specialItems.push("Portable steamer (for wrinkle-free clothes)")
  } else if (tripType === "family") {
    specialItems.push("Entertainment for kids (books, games, etc.)")
    specialItems.push("Snacks")
  }

  // Process special needs
  if (specialNeeds.toLowerCase().includes("meeting") || specialNeeds.toLowerCase().includes("formal")) {
    specialItems.push("Formal outfits for meetings/events")
  }

  if (specialNeeds.toLowerCase().includes("cold") || specialNeeds.toLowerCase().includes("winter")) {
    specialItems.push("Cold weather gear (gloves, scarf, hat)")
  }

  if (specialNeeds.toLowerCase().includes("hik") || specialNeeds.toLowerCase().includes("trek")) {
    specialItems.push("Hiking gear (boots, backpack, walking sticks)")
  }

  if (specialNeeds.toLowerCase().includes("baby") || specialNeeds.toLowerCase().includes("infant")) {
    specialItems.push("Baby essentials (diapers, wipes, formula, etc.)")
    specialItems.push("Baby carrier or stroller")
  }

  if (specialNeeds.toLowerCase().includes("camera") || specialNeeds.toLowerCase().includes("photo")) {
    specialItems.push("Camera and accessories")
  }

  // Add destination-specific items
  if (
    destination.toLowerCase().includes("beach") ||
    destination.toLowerCase().includes("hawaii") ||
    destination.toLowerCase().includes("caribbean")
  ) {
    if (!specialItems.includes("Sunscreen")) {
      specialItems.push("Sunscreen")
    }
  }

  // Simulate a delay to make it feel like processing
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return {
    essentials,
    clothing,
    specialItems: specialItems.length ? specialItems : ["No special items needed for this trip"],
  }
}
