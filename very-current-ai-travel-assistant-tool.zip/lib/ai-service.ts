import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

interface TripDetails {
  destination: string
  tripLength: string
  tripType: string
  specialNeeds?: string
}

interface Resource {
  name: string
  url: string
  type: "yelp" | "tripadvisor" | "official" | "google" | "other"
}

interface AITravelResponse {
  packingList: {
    essentials: string[]
    clothing: string[]
    specialItems: string[]
  }
  itinerary: {
    days: {
      day: number
      activities: string[]
      resources: Resource[]
    }[]
  }
  budget: {
    currency: string
    estimates: {
      accommodation: string
      food: string
      transportation: string
      activities: string
      total: string
    }
  }
}

export async function generateAITravelPlan(tripDetails: TripDetails): Promise<AITravelResponse> {
  const { destination, tripLength, tripType, specialNeeds } = tripDetails

  const prompt = `
    As a travel planning assistant, create a comprehensive travel plan for a trip with the following details:
    
    Destination: ${destination}
    Trip Length: ${tripLength}
    Trip Type: ${tripType}
    Special Needs/Interests: ${specialNeeds || "None specified"}
    
    Please provide the following in JSON format:
    
    1. A detailed packing list organized into three categories:
       - essentials: [list of essential items]
       - clothing: [list of clothing items appropriate for the destination, weather, and trip type]
       - specialItems: [list of special items based on trip type and activities]
    
    2. A suggested day-by-day itinerary with:
       - days: [array of day objects with day number, list of suggested activities, and resources]
       
       For each day, include a "resources" array with helpful links related to the activities, such as:
       [
         {
           "name": "Restaurant Name on Yelp",
           "url": "https://www.yelp.com/...",
           "type": "yelp"
         },
         {
           "name": "Attraction on TripAdvisor",
           "url": "https://www.tripadvisor.com/...",
           "type": "tripadvisor"
         },
         {
           "name": "Official Museum Website",
           "url": "https://www.museum.com/...",
           "type": "official"
         },
         {
           "name": "Location on Google Maps",
           "url": "https://maps.google.com/...",
           "type": "google"
         }
       ]
       
       Include at least 2-3 relevant resources for each day, with accurate URLs to Yelp, TripAdvisor, official websites, or Google Maps.
    
    3. A budget estimate in local currency with:
       - currency: [local currency code]
       - estimates: [breakdown of estimated costs for accommodation, food, transportation, activities, and total]
    
    Base your recommendations on the destination, trip length, trip type, and any special needs mentioned.
    Ensure the packing list is practical and tailored to the specific trip.
    The itinerary should include popular attractions and activities suitable for the trip type.
    The budget should be realistic for the destination and trip type.
    
    Return ONLY valid JSON without any additional text, explanations, or markdown formatting.
  `

  try {
    // Make sure we're using the environment variable for the API key
    const groqModel = groq("llama3-70b-8192", {
      apiKey: process.env.GROQ_API_KEY,
    })

    const { text } = await generateText({
      model: groqModel,
      prompt,
      temperature: 0.7,
      maxTokens: 4000,
    })

    // Parse the JSON response
    const response = JSON.parse(text) as AITravelResponse
    return response
  } catch (error) {
    console.error("Error generating AI travel plan:", error)

    // Return a fallback response
    return {
      packingList: {
        essentials: ["Passport/ID", "Phone charger", "Toiletries", "Medications"],
        clothing: ["Appropriate clothing for the trip length", "Comfortable shoes"],
        specialItems: ["Items specific to your trip type"],
      },
      itinerary: {
        days: [
          {
            day: 1,
            activities: ["Explore your destination", "Check in to accommodation"],
            resources: [
              {
                name: "Explore on TripAdvisor",
                url: "https://www.tripadvisor.com/",
                type: "tripadvisor",
              },
            ],
          },
        ],
      },
      budget: {
        currency: "USD",
        estimates: {
          accommodation: "Varies by destination",
          food: "Varies by destination",
          transportation: "Varies by destination",
          activities: "Varies by destination",
          total: "Please try again for a detailed estimate",
        },
      },
    }
  }
}
