import { PackingAssistant } from "@/components/packing-assistant"
import { WelcomePopup } from "@/components/welcome-popup"
import { HelpButton } from "@/components/help-button"
import { Heart, Sparkles, Flower } from "lucide-react"
import { DecorativePattern } from "@/components/decorative-pattern"
import { SparkleBackground } from "@/components/sparkle-background"
import { GlitterCursor } from "@/components/glitter-cursor"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50 to-white relative">
      <div className="absolute top-0 right-0 w-full h-64 overflow-hidden opacity-20 pointer-events-none">
        <div className="absolute -right-12 -top-12 w-64 h-64 rounded-full bg-pink-200"></div>
        <div className="absolute right-1/4 top-20 w-32 h-32 rounded-full bg-purple-200"></div>
        <div className="absolute left-1/3 top-10 w-48 h-48 rounded-full bg-pink-100"></div>
      </div>

      <DecorativePattern />
      <SparkleBackground />
      <GlitterCursor />

      <div className="container max-w-6xl mx-auto px-4 py-12 relative z-10">
        <div className="flex justify-between items-center mb-8">
          <div className="text-center flex-1">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-pink-800 mb-2 flex justify-center items-center gap-2">
              <Sparkles className="h-6 w-6 text-pink-500" />
              Travel Planner
              <Sparkles className="h-6 w-6 text-pink-500" />
            </h1>
            <p className="text-pink-700 max-w-2xl mx-auto">
              Plan your perfect getaway with our cute travel assistant! Get personalized packing lists, itineraries, and
              budget estimates.
            </p>
            <div className="flex justify-center gap-2 mt-2">
              <Heart className="h-4 w-4 text-pink-400" />
              <Flower className="h-4 w-4 text-pink-400" />
              <Heart className="h-4 w-4 text-pink-400" />
            </div>
          </div>
          <div className="hidden sm:block">
            <HelpButton />
          </div>
        </div>
        <PackingAssistant />
      </div>
      <WelcomePopup />
    </main>
  )
}
