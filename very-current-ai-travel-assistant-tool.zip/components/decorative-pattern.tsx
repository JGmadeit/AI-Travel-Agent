import { Heart, Sparkles, Flower } from "lucide-react"

export function DecorativePattern() {
  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-10 z-0">
      <div className="absolute top-10 left-[10%] text-pink-300">
        <Heart className="h-6 w-6" />
      </div>
      <div className="absolute top-[15%] left-[20%] text-purple-300">
        <Sparkles className="h-5 w-5" />
      </div>
      <div className="absolute top-[25%] left-[5%] text-pink-200">
        <Flower className="h-7 w-7" />
      </div>
      <div className="absolute top-[40%] left-[15%] text-pink-300">
        <Heart className="h-5 w-5" />
      </div>
      <div className="absolute top-[60%] left-[8%] text-purple-300">
        <Sparkles className="h-6 w-6" />
      </div>
      <div className="absolute top-[75%] left-[18%] text-pink-200">
        <Flower className="h-5 w-5" />
      </div>
      <div className="absolute top-[85%] left-[10%] text-pink-300">
        <Heart className="h-4 w-4" />
      </div>

      <div className="absolute top-10 right-[10%] text-pink-300">
        <Heart className="h-6 w-6" />
      </div>
      <div className="absolute top-[15%] right-[20%] text-purple-300">
        <Sparkles className="h-5 w-5" />
      </div>
      <div className="absolute top-[25%] right-[5%] text-pink-200">
        <Flower className="h-7 w-7" />
      </div>
      <div className="absolute top-[40%] right-[15%] text-pink-300">
        <Heart className="h-5 w-5" />
      </div>
      <div className="absolute top-[60%] right-[8%] text-purple-300">
        <Sparkles className="h-6 w-6" />
      </div>
      <div className="absolute top-[75%] right-[18%] text-pink-200">
        <Flower className="h-5 w-5" />
      </div>
      <div className="absolute top-[85%] right-[10%] text-pink-300">
        <Heart className="h-4 w-4" />
      </div>
    </div>
  )
}
