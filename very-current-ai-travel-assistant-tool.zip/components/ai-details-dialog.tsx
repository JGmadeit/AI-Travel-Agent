"use client"

import { useState } from "react"
import { Brain, MapPin, Calendar, Plane, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function AIDetailsDialog() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="link" size="sm" className="text-xs text-pink-500 p-0 h-auto font-normal underline-offset-4">
          Learn more about our travel planning system
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl text-pink-700 font-display">
            <Brain className="h-5 w-5 text-pink-500" />
            How Our Travel Planner Works
          </DialogTitle>
          <DialogDescription>The technology behind your personalized travel plans</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <p className="text-sm text-pink-700">
            Our travel planning system creates personalized recommendations by analyzing several factors:
          </p>

          <div className="space-y-4">
            <div className="bg-pink-50 p-3 rounded-lg border border-pink-100">
              <h3 className="font-medium text-pink-700 flex items-center gap-2 mb-1 font-display">
                <MapPin className="h-4 w-4" />
                Destination Analysis
              </h3>
              <p className="text-sm text-pink-600">
                We analyze your destination to understand local weather patterns, cultural norms, and popular
                attractions to create recommendations that are relevant to where you're going.
              </p>
            </div>

            <div className="bg-pink-50 p-3 rounded-lg border border-pink-100">
              <h3 className="font-medium text-pink-700 flex items-center gap-2 mb-1 font-display">
                <Calendar className="h-4 w-4" />
                Trip Duration Optimization
              </h3>
              <p className="text-sm text-pink-600">
                Based on your trip length, we calculate the optimal number of clothing items, create a day-by-day
                itinerary, and estimate appropriate budget allocations for your entire stay.
              </p>
            </div>

            <div className="bg-pink-50 p-3 rounded-lg border border-pink-100">
              <h3 className="font-medium text-pink-700 flex items-center gap-2 mb-1 font-display">
                <Plane className="h-4 w-4" />
                Trip Type Customization
              </h3>
              <p className="text-sm text-pink-600">
                Whether it's business, leisure, family, or adventure travel, we tailor recommendations to match your
                trip purpose, suggesting appropriate clothing, activities, and budget considerations.
              </p>
            </div>

            <div className="bg-pink-50 p-3 rounded-lg border border-pink-100">
              <h3 className="font-medium text-pink-700 flex items-center gap-2 mb-1 font-display">
                <Briefcase className="h-4 w-4" />
                Special Needs Adaptation
              </h3>
              <p className="text-sm text-pink-600">
                We process any special requirements or interests you mention to further personalize your packing list,
                itinerary suggestions, and budget estimates.
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
