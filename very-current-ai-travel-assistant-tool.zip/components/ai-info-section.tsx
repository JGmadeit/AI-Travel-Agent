import { Brain, MapPin, Calendar } from "lucide-react"
import { AIDetailsDialog } from "./ai-details-dialog"

export function AIInfoSection() {
  return (
    <div className="mt-6 p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border border-pink-100">
      <h4 className="text-sm font-medium text-pink-700 flex items-center gap-2 mb-2 font-display">
        <Brain className="h-4 w-4" />
        How Our Travel Planner Works
      </h4>
      <div className="space-y-3 text-xs">
        <div className="flex gap-2">
          <div className="bg-pink-100 p-1.5 rounded-full h-fit">
            <MapPin className="h-3 w-3 text-pink-500" />
          </div>
          <p className="text-pink-600">
            Our system analyzes your destination, trip length, and trip type to create a personalized packing list
            that's tailored to your journey.
          </p>
        </div>
        <div className="flex gap-2">
          <div className="bg-pink-100 p-1.5 rounded-full h-fit">
            <Calendar className="h-3 w-3 text-pink-500" />
          </div>
          <p className="text-pink-600">
            We consider factors like weather, activities, and local customs to suggest appropriate items to pack, places
            to visit, and budget estimates.
          </p>
        </div>
      </div>
      <div className="flex justify-center mt-3">
        <AIDetailsDialog />
      </div>
    </div>
  )
}
