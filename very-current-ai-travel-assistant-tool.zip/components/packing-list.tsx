"use client"

import type React from "react"

import { useState } from "react"
import { Check, Copy, Download, Luggage, Shirt, Sparkles, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface PackingListProps {
  packingList: {
    essentials: string[]
    clothing: string[]
    specialItems: string[]
  }
}

export function PackingList({ packingList }: PackingListProps) {
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({})
  const [copied, setCopied] = useState(false)

  const toggleItem = (category: string, index: number) => {
    const key = `${category}-${index}`
    setCheckedItems((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const copyToClipboard = () => {
    const text = [
      "# My Packing List\n",
      "## Essentials",
      ...packingList.essentials.map((item) => `- ${item}`),
      "\n## Clothing",
      ...packingList.clothing.map((item) => `- ${item}`),
      "\n## Special Items",
      ...packingList.specialItems.map((item) => `- ${item}`),
    ].join("\n")

    navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const downloadAsTxt = () => {
    const text = [
      "MY PACKING LIST\n",
      "ESSENTIALS:",
      ...packingList.essentials.map((item) => `- ${item}`),
      "\nCLOTHING:",
      ...packingList.clothing.map((item) => `- ${item}`),
      "\nSPECIAL ITEMS:",
      ...packingList.specialItems.map((item) => `- ${item}`),
    ].join("\n")

    const blob = new Blob([text], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "packing-list.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const renderCategory = (items: string[], category: string, icon: React.ReactNode) => (
    <div className="space-y-2">
      <div className="flex items-center gap-2 font-display font-medium text-lg text-pink-700">
        {icon}
        <h3>{category}</h3>
      </div>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-start gap-2">
            <Checkbox
              id={`${category}-${index}`}
              checked={checkedItems[`${category}-${index}`] || false}
              onCheckedChange={() => toggleItem(category, index)}
              className="mt-1"
            />
            <label
              htmlFor={`${category}-${index}`}
              className={`flex-1 cursor-pointer ${
                checkedItems[`${category}-${index}`] ? "line-through text-muted-foreground" : ""
              }`}
            >
              {item}
            </label>
          </li>
        ))}
      </ul>
    </div>
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-pink-700 font-display">
          <Luggage className="h-5 w-5 text-pink-500" />
          Your Packing List
          <Heart className="h-4 w-4 text-pink-400" />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {renderCategory(packingList.essentials, "Essentials", <Luggage className="h-4 w-4" />)}
        {renderCategory(packingList.clothing, "Clothing", <Shirt className="h-4 w-4" />)}
        {renderCategory(packingList.specialItems, "Special Items", <Sparkles className="h-4 w-4" />)}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          size="sm"
          className="border-pink-200 text-pink-700 hover:bg-pink-50 font-display"
          onClick={copyToClipboard}
        >
          {copied ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Copied
            </>
          ) : (
            <>
              <Copy className="mr-2 h-4 w-4" />
              Copy
            </>
          )}
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="border-pink-200 text-pink-700 hover:bg-pink-50 font-display"
          onClick={downloadAsTxt}
        >
          <Download className="mr-2 h-4 w-4" />
          Download
        </Button>
      </CardFooter>
    </Card>
  )
}
