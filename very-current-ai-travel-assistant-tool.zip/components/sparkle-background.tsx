"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Heart, Sparkles, Star } from "lucide-react"

interface FloatingElement {
  id: number
  x: number
  y: number
  size: number
  duration: number
  delay: number
  type: "sparkle" | "heart" | "star"
  color: string
}

export function SparkleBackground() {
  const [elements, setElements] = useState<FloatingElement[]>([])
  const colors = ["#F9A8D4", "#F472B6", "#C084FC", "#A78BFA", "#E879F9"]

  useEffect(() => {
    // Create initial floating elements
    const initialElements = Array.from({ length: 25 }, (_, i) => createFloatingElement(i))
    setElements(initialElements)

    // Add new elements periodically
    const interval = setInterval(() => {
      const newElement = createFloatingElement(Date.now())
      setElements((current) => [...current.slice(-30), newElement]) // Keep max 30 elements
    }, 800)

    return () => clearInterval(interval)
  }, [])

  function createFloatingElement(id: number): FloatingElement {
    const types = ["sparkle", "heart", "star"]
    return {
      id,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 12 + 8,
      duration: Math.random() * 8 + 6,
      delay: Math.random() * 2,
      type: types[Math.floor(Math.random() * types.length)] as "sparkle" | "heart" | "star",
      color: colors[Math.floor(Math.random() * colors.length)],
    }
  }

  const renderElement = (element: FloatingElement) => {
    switch (element.type) {
      case "sparkle":
        return <Sparkles style={{ width: "100%", height: "100%" }} />
      case "heart":
        return <Heart style={{ width: "100%", height: "100%" }} />
      case "star":
        return <Star style={{ width: "100%", height: "100%" }} />
    }
  }

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {elements.map((element) => (
        <motion.div
          key={element.id}
          initial={{
            opacity: 0,
            scale: 0,
            x: `${element.x}vw`,
            y: `${element.y}vh`,
          }}
          animate={{
            opacity: [0, 0.7, 0],
            scale: [0, 1, 0.5],
            y: [`${element.y}vh`, `${element.y - 15}vh`],
            x: [`${element.x}vw`, `${element.x + (Math.random() * 10 - 5)}vw`],
            rotate: [0, Math.random() * 360],
          }}
          transition={{
            duration: element.duration,
            delay: element.delay,
            ease: "easeInOut",
          }}
          style={{
            position: "absolute",
            color: element.color,
            width: `${element.size}px`,
            height: `${element.size}px`,
          }}
        >
          {renderElement(element)}
        </motion.div>
      ))}
    </div>
  )
}
