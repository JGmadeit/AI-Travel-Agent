"use client"

import { useState } from "react"
import { HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Bot, Luggage, CalendarDays, DollarSign, Sparkles, Heart } from "lucide-react"

export function HelpButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full text-pink-500 hover:text-pink-600 hover:bg-pink-100"
          aria-label="Help"
        >
          <HelpCircle className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl text-pink-700 font-display">
            <Bot className="h-6 w-6 text-pink-500" />
            How It Works
            <Sparkles className="h-5 w-5 text-pink-400" />
          </DialogTitle>
          <DialogDescription>Your intelligent companion for stress-free travel planning</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <p className="text-sm text-muted-foreground">
            This tool creates personalized travel plans based on your specific trip details. Here's what you'll get:
          </p>

          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="bg-pink-50 p-2 rounded-full h-fit">
                <Luggage className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium font-display">Smart Packing List</h3>
                <p className="text-sm text-muted-foreground">
                  Get a customized packing list tailored to your destination, trip length, and activities.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="bg-pink-50 p-2 rounded-full h-fit">
                <CalendarDays className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium font-display">Suggested Itinerary</h3>
                <p className="text-sm text-muted-foreground">
                  Receive day-by-day activity recommendations optimized for your destination and interests.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="bg-pink-50 p-2 rounded-full h-fit">
                <DollarSign className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium font-display">Budget Estimates</h3>
                <p className="text-sm text-muted-foreground">
                  View cost estimates in local currency for accommodation, food, transportation, and activities.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-pink-50 p-3 rounded-md text-sm border border-pink-100">
            <p className="font-medium text-pink-700 font-display">How to use:</p>
            <ol className="list-decimal pl-5 space-y-1 mt-1 text-pink-600">
              <li>Fill in your destination, trip length, and trip type</li>
              <li>Add any special needs or interests</li>
              <li>Click "Create My Travel Plan"</li>
              <li>View your personalized packing list, itinerary, and budget</li>
            </ol>
          </div>
        </div>
        <DialogFooter>
          <Button
            className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 font-display"
            onClick={() => setIsOpen(false)}
          >
            <Heart className="mr-1 h-4 w-4" /> Got it
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
