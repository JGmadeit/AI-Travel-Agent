"use client"

import { motion } from "framer-motion"
import { Sparkles } from "lucide-react"

export function SparkleLoader() {
  return (
    <div className="flex items-center justify-center gap-2">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      >
        <Sparkles className="h-5 w-5 text-pink-500" />
      </motion.div>
      <span>Creating your magical travel plan...</span>
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, -180, -360],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: 0.3,
        }}
      >
        <Sparkles className="h-5 w-5 text-purple-500" />
      </motion.div>
    </div>
  )
}
