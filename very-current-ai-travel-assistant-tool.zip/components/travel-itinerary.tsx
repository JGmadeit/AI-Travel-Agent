import { CalendarDays, MapPin, Sparkles, ExternalLink, Info } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface Resource {
  name: string
  url: string
  type: "yelp" | "tripadvisor" | "official" | "google" | "other"
}

interface TravelItineraryProps {
  itinerary: {
    days: {
      day: number
      activities: string[]
      resources?: Resource[]
    }[]
  }
  destination: string
}

export function TravelItinerary({ itinerary, destination }: TravelItineraryProps) {
  // Function to get the appropriate icon color based on resource type
  const getResourceColor = (type: Resource["type"]) => {
    switch (type) {
      case "yelp":
        return "text-red-500"
      case "tripadvisor":
        return "text-green-600"
      case "official":
        return "text-blue-600"
      case "google":
        return "text-yellow-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-pink-700 font-display">
          <CalendarDays className="h-5 w-5 text-pink-500" />
          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
            <span>Suggested Itinerary</span>
            <div className="flex items-center text-sm font-normal text-pink-500">
              <MapPin className="h-3 w-3 mr-1" />
              {destination}
            </div>
          </div>
          <Sparkles className="h-4 w-4 text-pink-400 ml-auto sm:ml-0" />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {itinerary.days.map((day) => (
            <AccordionItem key={day.day} value={`day-${day.day}`}>
              <AccordionTrigger className="hover:no-underline text-pink-700 font-display">
                <span className="font-medium">Day {day.day}</span>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-2 pl-2">
                  {day.activities.map((activity, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <div className="min-w-5 h-5 rounded-full bg-pink-100 text-pink-700 flex items-center justify-center text-xs font-medium mt-0.5">
                        {index + 1}
                      </div>
                      <span>{activity}</span>
                    </li>
                  ))}
                </ul>

                {day.resources && day.resources.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-pink-100">
                    <div className="flex items-center gap-1 text-sm font-medium text-pink-600 mb-2 font-display">
                      <Info className="h-4 w-4" />
                      <span>Helpful Resources:</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <TooltipProvider>
                        {day.resources.map((resource, index) => (
                          <Tooltip key={index}>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className={`text-xs border-pink-200 ${getResourceColor(resource.type)} font-display`}
                                asChild
                              >
                                <a
                                  href={resource.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1"
                                >
                                  {resource.name}
                                  <ExternalLink className="h-3 w-3" />
                                </a>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>
                                Visit{" "}
                                {resource.type === "yelp"
                                  ? "Yelp"
                                  : resource.type === "tripadvisor"
                                    ? "TripAdvisor"
                                    : resource.type === "official"
                                      ? "Official Website"
                                      : resource.type === "google"
                                        ? "Google Maps"
                                        : "Website"}
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        ))}
                      </TooltipProvider>
                    </div>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  )
}
