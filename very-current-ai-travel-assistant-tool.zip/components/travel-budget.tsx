import { DollarSign, MapPin } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sparkles } from "lucide-react"

interface TravelBudgetProps {
  budget: {
    currency: string
    estimates: {
      accommodation: string
      food: string
      transportation: string
      activities: string
      total: string
    }
  }
  destination: string
}

export function TravelBudget({ budget, destination }: TravelBudgetProps) {
  const { currency, estimates } = budget

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-pink-700 font-display">
          <DollarSign className="h-5 w-5 text-pink-500" />
          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
            <span>Estimated Budget</span>
            <div className="flex items-center text-sm font-normal text-pink-500">
              <MapPin className="h-3 w-3 mr-1" />
              {destination}
            </div>
          </div>
          <Sparkles className="h-4 w-4 text-pink-400 ml-auto sm:ml-0" />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-pink-600 font-display">Accommodation</h4>
              <p className="text-lg font-medium">
                {estimates.accommodation} {currency}
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-pink-600 font-display">Food</h4>
              <p className="text-lg font-medium">
                {estimates.food} {currency}
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-pink-600 font-display">Transportation</h4>
              <p className="text-lg font-medium">
                {estimates.transportation} {currency}
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-pink-600 font-display">Activities</h4>
              <p className="text-lg font-medium">
                {estimates.activities} {currency}
              </p>
            </div>
          </div>
          <div className="pt-4 border-t border-pink-200">
            <div className="flex justify-between items-center">
              <h4 className="font-medium text-pink-700 font-display">Total Estimated Budget</h4>
              <p className="text-xl font-bold text-pink-700">
                {estimates.total} {currency}
              </p>
            </div>
            <p className="text-xs text-pink-500 mt-2">
              *Prices are estimates and may vary based on season, accommodation choices, and personal preferences.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
