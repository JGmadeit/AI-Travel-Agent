"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { SparklesIcon } from "lucide-react"

interface Sparkle {
  id: number
  x: number
  y: number
  size: number
  rotation: number
  color: string
}

export function AnimatedSparkles() {
  const [sparkles, setSparkles] = useState<Sparkle[]>([])
  const colors = ["#F9A8D4", "#F472B6", "#C084FC", "#A78BFA", "#E879F9"]

  useEffect(() => {
    // Create initial sparkles
    const initialSparkles = Array.from({ length: 15 }, (_, i) => createSparkle(i))
    setSparkles(initialSparkles)

    // Add new sparkles periodically
    const interval = setInterval(() => {
      setSparkles((currentSparkles) => {
        // Remove oldest sparkle if we have more than 20
        const updatedSparkles = currentSparkles.length >= 20 ? currentSparkles.slice(1) : [...currentSparkles]

        // Add a new sparkle
        return [...updatedSparkles, createSparkle(Date.now())]
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  function createSparkle(id: number): Sparkle {
    return {
      id,
      x: Math.random() * 100, // % of viewport width
      y: Math.random() * 100, // % of viewport height
      size: Math.random() * 10 + 5, // between 5-15px
      rotation: Math.random() * 360,
      color: colors[Math.floor(Math.random() * colors.length)],
    }
  }

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      <AnimatePresence>
        {sparkles.map((sparkle) => (
          <motion.div
            key={sparkle.id}
            initial={{
              opacity: 0,
              scale: 0,
              x: `${sparkle.x}vw`,
              y: `${sparkle.y}vh`,
              rotate: sparkle.rotation,
            }}
            animate={{
              opacity: [0, 1, 0.8, 0],
              scale: [0, 1, 0.8, 0],
              y: `${sparkle.y - 10}vh`,
              transition: { duration: 4, ease: "easeOut" },
            }}
            exit={{ opacity: 0 }}
            style={{
              position: "absolute",
              color: sparkle.color,
            }}
          >
            <SparklesIcon
              style={{
                width: `${sparkle.size}px`,
                height: `${sparkle.size}px`,
              }}
            />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
