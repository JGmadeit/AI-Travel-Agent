import { Bot } from "lucide-react"

export function AIBadge() {
  return (
    <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-pink-100 text-pink-700 hover:bg-pink-200">
      <Bot className="mr-1 h-3 w-3" />
      AI Powered
    </div>
  )
}
