"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles } from "lucide-react"

interface GlitterParticle {
  id: number
  x: number
  y: number
  size: number
  color: string
}

export function GlitterCursor() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [particles, setParticles] = useState<GlitterParticle[]>([])
  const colors = ["#F9A8D4", "#F472B6", "#C084FC", "#A78BFA", "#E879F9"]

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })

      // Add new particle
      const newParticle = {
        id: Date.now(),
        x: e.clientX,
        y: e.clientY,
        size: Math.random() * 10 + 5,
        color: colors[Math.floor(Math.random() * colors.length)],
      }

      setParticles((current) => [...current.slice(-15), newParticle]) // Keep max 15 particles
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      <AnimatePresence>
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            initial={{ opacity: 0.8, scale: 1, x: particle.x, y: particle.y }}
            animate={{
              opacity: 0,
              scale: 0,
              x: particle.x + (Math.random() * 40 - 20),
              y: particle.y + (Math.random() * 40 - 20),
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            style={{
              position: "absolute",
              left: -10,
              top: -10,
              color: particle.color,
            }}
          >
            <Sparkles style={{ width: `${particle.size}px`, height: `${particle.size}px` }} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
