"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Plane, Luggage, MapPin, Calendar, Sparkles, AlertCircle, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { PackingList } from "@/components/packing-list"
import { TravelItinerary } from "@/components/travel-itinerary"
import { TravelBudget } from "@/components/travel-budget"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIBadge } from "@/components/ai-badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { SparkleLoader } from "@/components/sparkle-loader"
import { AIInfoSection } from "@/components/ai-info-section"

const formSchema = z.object({
  destination: z.string().min(2, {
    message: "Destination must be at least 2 characters.",
  }),
  tripLength: z.string().min(1, {
    message: "Trip length is required.",
  }),
  tripType: z.string().min(1, {
    message: "Trip type is required.",
  }),
  specialNeeds: z.string().optional(),
})

export function PackingAssistant() {
  const [travelPlan, setTravelPlan] = useState<null | {
    packingList: {
      essentials: string[]
      clothing: string[]
      specialItems: string[]
    }
    itinerary: {
      days: {
        day: number
        activities: string[]
        resources?: {
          name: string
          url: string
          type: "yelp" | "tripadvisor" | "official" | "google" | "other"
        }[]
      }[]
    }
    budget: {
      currency: string
      estimates: {
        accommodation: string
        food: string
        transportation: string
        activities: string
        total: string
      }
    }
  }>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      destination: "",
      tripLength: "",
      tripType: "",
      specialNeeds: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsGenerating(true)
    setError(null)

    try {
      // Call the API route instead of the AI service directly
      const response = await fetch("/api/generate-travel-plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`)
      }

      const plan = await response.json()
      setTravelPlan(plan)
    } catch (error) {
      console.error("Failed to generate travel plan:", error)
      setError("Failed to generate travel plan. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-display">
            <Luggage className="h-5 w-5" />
            Trip Details
          </CardTitle>
          <CardDescription>Fill in your trip information to get a customized travel plan</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle className="font-display">Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="destination"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1 font-display">
                      <MapPin className="h-4 w-4" />
                      Destination
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="New York City, Paris, etc." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="tripLength"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1 font-display">
                      <Calendar className="h-4 w-4" />
                      Trip Length
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="5 days, 2 weeks, etc." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="tripType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1 font-display">
                      <Plane className="h-4 w-4" />
                      Trip Type
                    </FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select trip type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="leisure">Leisure</SelectItem>
                        <SelectItem value="family">Family</SelectItem>
                        <SelectItem value="adventure">Adventure</SelectItem>
                        <SelectItem value="beach">Beach</SelectItem>
                        <SelectItem value="winter">Winter</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="specialNeeds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-1 font-display">
                      <Sparkles className="h-4 w-4" />
                      Special Needs & Interests
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="E.g., Need outfits for client meetings, interested in local cuisine, traveling with children, etc."
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Any specific requirements, interests, or activities planned for your trip
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 rounded-full font-display"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <SparkleLoader />
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Sparkles className="h-4 w-4" />
                    Create My Travel Plan
                    <AIBadge />
                  </span>
                )}
              </Button>
            </form>
          </Form>

          {/* Add the AI Info Section here */}
          <AIInfoSection />
        </CardContent>
      </Card>

      {travelPlan ? (
        <div className="space-y-6">
          <Tabs defaultValue="packing">
            <TabsList className="grid w-full grid-cols-3 font-display">
              <TabsTrigger value="packing">Packing List</TabsTrigger>
              <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
              <TabsTrigger value="budget">Budget</TabsTrigger>
            </TabsList>
            <TabsContent value="packing">
              <PackingList packingList={travelPlan.packingList} />
            </TabsContent>
            <TabsContent value="itinerary">
              <TravelItinerary itinerary={travelPlan.itinerary} destination={form.getValues().destination} />
            </TabsContent>
            <TabsContent value="budget">
              <TravelBudget budget={travelPlan.budget} destination={form.getValues().destination} />
            </TabsContent>
          </Tabs>
        </div>
      ) : (
        <Card className="flex flex-col justify-center items-center bg-gradient-to-r from-pink-50 to-purple-50 border-pink-200">
          <CardContent className="pt-6 text-center">
            <div className="relative">
              <Luggage className="h-16 w-16 text-pink-300 mb-4" />
              <Sparkles className="h-6 w-6 text-pink-400 absolute -top-2 -right-2" />
            </div>
            <h3 className="text-xl font-display font-medium text-pink-700">Your travel plan will appear here</h3>
            <p className="text-sm text-pink-600 mt-2">Fill out the form with your trip details to get started</p>
            <div className="flex justify-center gap-2 mt-4">
              <Heart className="h-4 w-4 text-pink-300" />
              <Heart className="h-4 w-4 text-pink-300" />
              <Heart className="h-4 w-4 text-pink-300" />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
